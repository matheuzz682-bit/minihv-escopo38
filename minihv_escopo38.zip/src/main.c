#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "config/config.h"
#include "cpu/loader.h"
#include "cpu/cpu.h"
#include "log/log.h"
#include "util/prng.h"
#include "vm/vm.h"
#include "sched/sjf.h"
#include "mem/pag.h"
#include "disk/clook.h"
#include "watchdog/watchdog.h"

int main(int argc, char *argv[]) {
    HostConfig cfg;
    const char *conf_file = (argc > 2 && strcmp(argv[1], "-c") == 0) ? argv[2] : "conf/hv.conf";

    if (!config_load(conf_file, &cfg)) {
        fprintf(stderr, "Erro ao carregar configuração.\n");
        return 1;
    }

    prng_seed(cfg.seed);

    FILE *log_stream = fopen(cfg.log_file, "w");
    log_event(log_stream, 0, "INFO", "hv", "-", "VM_CREATE", "Iniciando MiniHV Completo (SJF + PAG CLOCK + C-LOOK)");

    // Inicializar Memória Física
    PhysicalMemory phys_mem;
    pag_init(&phys_mem, cfg.phys_words, cfg.page_words);

    // Inicializar Controlador de Disco C-LOOK
    DiskController disk;
    disk_init(&disk, cfg.disk_cylinders, cfg.disk_head, cfg.seek_rate);

    // Inicializar Watchdog
    Watchdog wd;
    watchdog_init(&wd, cfg.max_ticks);

    #define NUM_VMS 2
    VirtualMachine vms[NUM_VMS];

    // VM 0
    strcpy(vms[0].name, "vm_alpha");
    vms[0].state = VM_READY;
    vms[0].burst_time = 15;
    cpu_init(&vms[0].cpu);
    if (!loader_load("progs/contador.mv", &vms[0].prog)) {
        fprintf(stderr, "Erro ao carregar vm_alpha.\n");
    }
    pag_allocate_frame(&phys_mem, 0, 0);

    // VM 1 (SJF prioriza esta por ter menor burst_time)
    strcpy(vms[1].name, "vm_beta");
    vms[1].state = VM_READY;
    vms[1].burst_time = 8;
    cpu_init(&vms[1].cpu);
    if (!loader_load("progs/contador.mv", &vms[1].prog)) {
        fprintf(stderr, "Erro ao carregar vm_beta.\n");
    }
    pag_allocate_frame(&phys_mem, 1, 0);

    uint64_t tick = 1;
    while (tick <= (uint64_t)cfg.max_ticks) {
        if (watchdog_check(&wd, tick)) {
            log_event(log_stream, tick, "WARN", "hv", "-", "WATCHDOG", "Limite de ticks atingido");
            break;
        }

        // Seleção de processo via Escalonador SJF
        int next_vm = sjf_select_next(vms, NUM_VMS);
        if (next_vm == -1) {
            log_event(log_stream, tick, "INFO", "hv", "-", "IDLE", "Nenhuma VM pronta");
            break;
        }

        vms[next_vm].state = VM_RUNNING;
        bool active = cpu_step(&vms[next_vm].cpu, &vms[next_vm].prog, tick);

        // Simulação de pedido de E/S para testar o disco C-LOOK
        if (tick % 4 == 0) {
            int cylinder_target = (int)(tick * 13) % cfg.disk_cylinders;
            disk_add_request(&disk, cylinder_target);
            log_event(log_stream, tick, "INFO", "disk", vms[next_vm].name, "IO_REQ", "Pedido de cilindro gerado");
        }

        // Processar um passo do disco C-LOOK
        int serviced = disk_step_clook(&disk);
        if (serviced != -1) {
            // E/S atendida com sucesso
        }

        if (!active) {
            vms[next_vm].state = VM_TERMINATED;
            log_event(log_stream, tick, "INFO", "hv", vms[next_vm].name, "VM_EXIT", "Processo terminado");
            vms[next_vm].burst_time = UINT32_MAX;
        } else {
            vms[next_vm].state = VM_READY;
        }

        tick++;
    }

    pag_free(&phys_mem);
    if (log_stream) fclose(log_stream);

    printf("MiniHV (Escopo 38) concluído com sucesso até ao tick %llu!\n", (unsigned long long)tick);
    return 0;
}
