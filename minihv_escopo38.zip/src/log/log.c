#include "log.h"

void log_event(FILE *stream, uint64_t tick, const char *level, const char *module, const char *vm, const char *event, const char *detail) {
    if (!stream) return;
    fprintf(stream, "{\"tick\":%llu,\"level\":\"%s\",\"module\":\"%s\",\"vm\":\"%s\",\"event\":\"%s\",\"detail\":\"%s\"}\n",
        (unsigned long long)tick, level, module, vm ? vm : "-", event, detail);
}
