#ifndef LOG_H
#define LOG_H
#include <stdint.h>
#include <stdio.h>
void log_event(FILE *stream, uint64_t tick, const char *level, const char *module, const char *vm, const char *event, const char *detail);
#endif
