#ifndef CPU_H
#define CPU_H

#include <stdint.h>
#include <stdbool.h>
#include "loader.h"

typedef struct {
    int32_t r[4]; // Registradores R0 a R3
    int pc;       // Program Counter
    bool halted;  // Estado de execução
} CPU;

void cpu_init(CPU *cpu);
bool cpu_step(CPU *cpu, Program *prog, uint64_t tick);

#endif
