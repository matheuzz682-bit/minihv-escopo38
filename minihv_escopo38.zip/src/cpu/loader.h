#ifndef LOADER_H
#define LOADER_H

#include <stdbool.h>

#define MAX_INSTRUCTIONS 256

typedef struct {
    char raw[256];
} Instruction;

typedef struct {
    Instruction instructions[MAX_INSTRUCTIONS];
    int count;
} Program;

bool loader_load(const char *filename, Program *prog);

#endif
