#include "loader.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool loader_load(const char *filename, Program *prog) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Erro ao abrir programa MV-ISA");
        return false;
    }

    prog->count = 0;
    char line[256];
    while (fgets(line, sizeof(line), f) && prog->count < MAX_INSTRUCTIONS) {
        // Remover quebra de linha
        line[strcspn(line, "\r\n")] = 0;
        // Ignorar linhas vazias ou comentários
        if (line[0] == '\0' || line[0] == ';') continue;

        strncpy(prog->instructions[prog->count].raw, line, sizeof(prog->instructions[prog->count].raw) - 1);
        prog->count++;
    }

    fclose(f);
    return true;
}
