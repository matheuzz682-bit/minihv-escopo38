#include "cpu.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void cpu_init(CPU *cpu) {
    for (int i = 0; i < 4; i++) {
        cpu->r[i] = 0;
    }
    cpu->pc = 0;
    cpu->halted = false;
}

bool cpu_step(CPU *cpu, Program *prog, uint64_t tick) {
    if (cpu->halted || cpu->pc >= prog->count) return false;

    Instruction *inst = &prog->instructions[cpu->pc];
    int r1 = 0, r2_or_imm = 0;

    // Decodificar instrução básica da MV-ISA
    if (sscanf(inst->raw, "MOV R%d, %d", &r1, &r2_or_imm) == 2) {
        if (r1 >= 0 && r1 < 4) cpu->r[r1] = r2_or_imm;
        cpu->pc++;
    } else if (sscanf(inst->raw, "OUT R%d", &r1) == 1) {
        if (r1 >= 0 && r1 < 4) {
            printf("[t=%04lu] web: %d\n", (unsigned long)tick, cpu->r[r1]);
        }
        cpu->pc++;
    } else if (sscanf(inst->raw, "SUB R%d, R%d", &r1, &r2_or_imm) == 2) {
        if (r1 >= 0 && r1 < 4 && r2_or_imm >= 0 && r2_or_imm < 4) {
            cpu->r[r1] -= cpu->r[r2_or_imm];
        }
        cpu->pc++;
    } else if (sscanf(inst->raw, "JNZ R%d, %d", &r1, &r2_or_imm) == 2) {
        if (r1 >= 0 && r1 < 4) {
            if (cpu->r[r1] != 0) {
                cpu->pc = r2_or_imm;
            } else {
                cpu->pc++;
            }
        }
    } else if (strcmp(inst->raw, "HALT") == 0) {
        cpu->halted = true;
    } else {
        cpu->pc++;
    }

    return !cpu->halted;
}
