#include "prng.h"
static uint32_t current_seed = 2026;
void prng_seed(uint32_t seed) { current_seed = seed; }
uint32_t prng_next(void) {
    current_seed = (1103515245U * current_seed + 12345U) & 0x7FFFFFFF;
    return current_seed;
}
