#include "sjf.h"
#include <stdint.h>

int sjf_select_next(VirtualMachine *vms, int count) {
    int selected = -1;
    uint32_t min_burst = UINT32_MAX;

    for (int i = 0; i < count; i++) {
        if (vms[i].state == VM_READY) {
            if (vms[i].burst_time < min_burst) {
                min_burst = vms[i].burst_time;
                selected = i;
            }
        }
    }
    return selected;
}
