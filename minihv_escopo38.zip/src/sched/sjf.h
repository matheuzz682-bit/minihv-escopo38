#ifndef SJF_H
#define SJF_H

#include "vm/vm.h"

int sjf_select_next(VirtualMachine *vms, int count);

#endif
