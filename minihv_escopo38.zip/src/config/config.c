#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool config_load(const char *filename, HostConfig *cfg) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Erro ao abrir arquivo de configuração");
        return false;
    }

    cfg->pcpus = 1;
    cfg->max_vms = 4;
    cfg->max_ticks = 5000;
    cfg->seed = 2026;
    strcpy(cfg->policy, "SJF");
    strcpy(cfg->mem_model, "PAG");
    cfg->phys_words = 2048;
    cfg->page_words = 128;
    strcpy(cfg->replacement, "CLOCK");
    strcpy(cfg->repl_scope, "LOCAL");
    cfg->pf_penalty = 3;
    strcpy(cfg->disk_algorithm, "C_LOOK");
    cfg->disk_cylinders = 200;
    cfg->disk_head = 50;
    cfg->seek_rate = 25;
    strcpy(cfg->log_format, "JSONL");
    strcpy(cfg->log_level, "INFO");
    strcpy(cfg->log_file, "out/minihv.jsonl");
    cfg->ext_enabled = true;
    cfg->ext_limit = 200;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == ';' || line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;
    }

    fclose(f);
    return true;
}
