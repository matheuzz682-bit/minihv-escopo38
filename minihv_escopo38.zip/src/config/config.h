#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    int pcpus;
    int max_vms;
    int max_ticks;
    uint32_t seed;
    char policy[32];
    char mem_model[32];
    int phys_words;
    int page_words;
    char replacement[32];
    char repl_scope[32];
    int pf_penalty;
    char disk_algorithm[32];
    int disk_cylinders;
    int disk_head;
    int seek_rate;
    char log_format[32];
    char log_level[32];
    char log_file[128];
    bool ext_enabled;
    int ext_limit;
} HostConfig;

bool config_load(const char *filename, HostConfig *cfg);

#endif
