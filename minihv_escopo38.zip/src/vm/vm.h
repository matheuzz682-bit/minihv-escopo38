#ifndef VM_H
#define VM_H

#include <stdint.h>
#include <stdbool.h>
#include "cpu/cpu.h"
#include "cpu/loader.h"

typedef enum {
    VM_READY,
    VM_RUNNING,
    VM_WAITING,
    VM_TERMINATED
} VMState;

typedef struct {
    char name[32];
    Program prog;
    CPU cpu;
    VMState state;
    int arrival;
    int priority;
    int mem_words;
    uint32_t burst_time; // Necessário para o SJF
} VirtualMachine;

#endif
