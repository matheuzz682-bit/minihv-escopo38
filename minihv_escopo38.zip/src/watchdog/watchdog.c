#include "watchdog.h"

void watchdog_init(Watchdog *wd, uint64_t max_ticks) {
    wd->max_ticks = max_ticks;
    wd->current_tick = 0;
}

bool watchdog_check(Watchdog *wd, uint64_t current_tick) {
    wd->current_tick = current_tick;
    return wd->current_tick >= wd->max_ticks;
}
