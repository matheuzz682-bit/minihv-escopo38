#ifndef WATCHDOG_H
#define WATCHDOG_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint64_t max_ticks;
    uint64_t current_tick;
} Watchdog;

void watchdog_init(Watchdog *wd, uint64_t max_ticks);
bool watchdog_check(Watchdog *wd, uint64_t current_tick);

#endif
