#include "pag.h"
#include <stdlib.h>

void pag_init(PhysicalMemory *mem, int phys_words, int page_words) {
    mem->phys_words = phys_words;
    mem->page_words = page_words;
    mem->num_frames = phys_words / page_words;
    mem->hand = 0;
    mem->frame_owner = malloc(mem->num_frames * sizeof(int));
    for (int i = 0; i < mem->num_frames; i++) {
        mem->frame_owner[i] = -1;
    }
}

void pag_free(PhysicalMemory *mem) {
    if (mem->frame_owner) {
        free(mem->frame_owner);
        mem->frame_owner = NULL;
    }
}

int pag_allocate_frame(PhysicalMemory *mem, int vm_id, int page_id) {
    // Algoritmo CLOCK LOCAL simplificado para alocação de frames
    (void)page_id;
    for (int i = 0; i < mem->num_frames; i++) {
        int frame = (mem->hand + i) % mem->num_frames;
        if (mem->frame_owner[frame] == -1) {
            mem->frame_owner[frame] = vm_id;
            mem->hand = (frame + 1) % mem->num_frames;
            return frame;
        }
    }
    // Se estiver cheio, substitui usando a mão do clock
    int frame = mem->hand;
    mem->frame_owner[frame] = vm_id;
    mem->hand = (frame + 1) % mem->num_frames;
    return frame;
}
