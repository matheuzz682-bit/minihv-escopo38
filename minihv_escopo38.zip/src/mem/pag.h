#ifndef PAG_H
#define PAG_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    int frame_id;
    bool valid;
    bool reference_bit; // Usado pelo algoritmo CLOCK LOCAL
} PageTableEntry;

typedef struct {
    int phys_words;
    int page_words;
    int num_frames;
    int hand; // Apontador do CLOCK
    int *frame_owner; // Guarda qual VM/página ocupa cada frame físico
} PhysicalMemory;

void pag_init(PhysicalMemory *mem, int phys_words, int page_words);
void pag_free(PhysicalMemory *mem);
int pag_allocate_frame(PhysicalMemory *mem, int vm_id, int page_id);

#endif
