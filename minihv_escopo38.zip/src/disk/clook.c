#include "clook.h"
#include <stdlib.h>

void disk_init(DiskController *disk, int cylinders, int initial_head, int seek_rate) {
    disk->cylinders = cylinders;
    disk->current_head = initial_head;
    disk->seek_rate = seek_rate;
    disk->queue_size = 0;
}

bool disk_add_request(DiskController *disk, int cylinder) {
    if (disk->queue_size < 64 && cylinder >= 0 && cylinder < disk->cylinders) {
        disk->queue[disk->queue_size++] = cylinder;
        return true;
    }
    return false;
}

int disk_step_clook(DiskController *disk) {
    if (disk->queue_size == 0) return -1;

    int best_idx = -1;
    int min_dist = 999999;
    int fallback_idx = -1;
    int min_cylinder = 999999;

    for (int i = 0; i < disk->queue_size; i++) {
        int c = disk->queue[i];
        if (c >= disk->current_head) {
            int dist = c - disk->current_head;
            if (dist < min_dist) {
                min_dist = dist;
                best_idx = i;
            }
        }
        if (c < min_cylinder) {
            min_cylinder = c;
            fallback_idx = i;
        }
    }

    if (best_idx == -1) {
        best_idx = fallback_idx;
    }

    int target = disk->queue[best_idx];
    disk->current_head = target;

    for (int i = best_idx; i < disk->queue_size - 1; i++) {
        disk->queue[i] = disk->queue[i + 1];
    }
    disk->queue_size--;

    return target;
}
