#ifndef CLOOK_H
#define CLOOK_H

#include <stdbool.h>

typedef struct {
    int cylinders;
    int current_head;
    int seek_rate;
    int queue[64];
    int queue_size;
} DiskController;

void disk_init(DiskController *disk, int cylinders, int initial_head, int seek_rate);
bool disk_add_request(DiskController *disk, int cylinder);
int disk_step_clook(DiskController *disk);

#endif
